import json, urllib.request
SUCCESS = "SUCCESS"
FAILED = "FAILED"
def send(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False):
    responseUrl = event["ResponseURL"]
    body = {
        "Status": responseStatus,
        "Reason": f"See CloudWatch logs: {getattr(context,'log_stream_name','')}",
        "PhysicalResourceId": physicalResourceId or getattr(context,'log_stream_name',''),
        "StackId": event["StackId"],
        "RequestId": event["RequestId"],
        "LogicalResourceId": event["LogicalResourceId"],
        "NoEcho": noEcho,
        "Data": responseData or {},
    }
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(responseUrl, data=data, method="PUT", headers={"content-type":"", "content-length":str(len(data))})
    with urllib.request.urlopen(req) as resp:
        resp.read()
