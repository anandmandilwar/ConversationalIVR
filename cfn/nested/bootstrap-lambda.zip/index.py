import json
import os
import traceback
import boto3
import urllib3

http = urllib3.PoolManager()

apigw = boto3.client("apigateway")
agentcore = boto3.client("bedrock-agentcore-control")


def cfn_send(event, context, status, data, physical_id=None, reason=None):
    body = {
        "Status": status,
        "Reason": reason or f"See logs: {context.log_stream_name}",
        "PhysicalResourceId": physical_id or context.log_stream_name,
        "StackId": event["StackId"],
        "RequestId": event["RequestId"],
        "LogicalResourceId": event["LogicalResourceId"],
        "Data": data or {},
    }
    encoded = json.dumps(body).encode("utf-8")
    http.request(
        "PUT",
        event["ResponseURL"],
        body=encoded,
        headers={"content-type": "", "content-length": str(len(encoded))},
    )


def _find_existing_provider(name):
    try:
        resp = agentcore.list_api_key_credential_providers()
        print(f"list_api_key_credential_providers response keys: {list(resp.keys())}")
        providers = (
            resp.get("credentialProviders", []) or
            resp.get("apiKeyCredentialProviders", []) or
            resp.get("items", [])
        )
        for provider in providers:
            if provider.get("name") == name:
                return provider
    except Exception as e:
        print(f"Could not list credential providers: {e}")
    return None


def _extract_arn(response, context_name=""):
    for key in [
        "arn", "providerArn", "credentialProviderArn",
        "Arn", "ProviderArn", "CredentialProviderArn",
        "apiKeyCredentialProviderArn",
    ]:
        val = response.get(key)
        if val and isinstance(val, str) and val.startswith("arn:"):
            return val

    for wrapper_key in ["credentialProvider", "apiKeyCredentialProvider"]:
        nested = response.get(wrapper_key, {})
        if isinstance(nested, dict):
            for arn_key in ["arn", "providerArn", "credentialProviderArn"]:
                val = nested.get(arn_key)
                if val and isinstance(val, str) and val.startswith("arn:"):
                    return val

    print(f"WARNING: Could not find ARN for '{context_name}'. Response keys: {list(response.keys())}")
    print(f"WARNING: Full response: {json.dumps(response, default=str)}")
    raise Exception(
        f"Could not extract credential provider ARN from response. "
        f"Keys: {list(response.keys())}. "
        f"Response: {json.dumps(response, default=str)}"
    )


def handler(event, context):
    props = event.get("ResourceProperties", {})
    req = event.get("RequestType", "Create")

    api_key_id = props["ApiGatewayApiKeyId"]
    provider_name = props["ProviderName"]

    print(f"Request: {req}")
    print(f"Properties: ApiKeyId={api_key_id}, ProviderName={provider_name}")

    physical_id = event.get("PhysicalResourceId")

    try:
        if req in ("Create", "Update"):
            k = apigw.get_api_key(apiKey=api_key_id, includeValue=True)
            api_key_value = k.get("value")
            if not api_key_value:
                raise Exception("API Gateway get_api_key(includeValue=True) did not return 'value'.")
            print(f"Retrieved API key value (length={len(api_key_value)})")

            try:
                agentcore.create_token_vault(name="default")
                print("Created token vault 'default'")
            except Exception as e:
                print(f"Token vault note: {e}")

            provider_arn = ""
            existing = _find_existing_provider(provider_name)
            if existing:
                provider_arn = _extract_arn(existing, provider_name)
                print(f"Found existing credential provider: {provider_arn}")
            else:
                print(f"Creating credential provider: {provider_name}")
                p = agentcore.create_api_key_credential_provider(
                    name=provider_name,
                    apiKey=api_key_value
                )
                print(f"Create credential provider response keys: {list(p.keys())}")
                print(f"Create credential provider response: {json.dumps(p, default=str)}")
                provider_arn = _extract_arn(p, provider_name)
                print(f"Created credential provider: {provider_arn}")

            if not provider_arn or not provider_arn.startswith("arn:"):
                raise Exception(f"Invalid provider ARN after creation: '{provider_arn}'")

            physical_id = provider_arn

            print(f"SUCCESS: ProviderArn={provider_arn}")
            cfn_send(
                event,
                context,
                "SUCCESS",
                {"ApiKeyCredentialProviderArn": provider_arn},
                physical_id=physical_id,
            )
            return

        if req == "Delete":
            print(f"Delete request. PhysicalResourceId={physical_id}")
            cfn_send(event, context, "SUCCESS", {}, physical_id=physical_id or context.log_stream_name)
            return

        cfn_send(event, context, "SUCCESS", {}, physical_id=physical_id or context.log_stream_name)

    except Exception as e:
        reason = f"{e}\n{traceback.format_exc(limit=5)}"
        print(f"ERROR: {reason}")
        cfn_send(event, context, "FAILED", {}, physical_id=physical_id or context.log_stream_name, reason=reason)
